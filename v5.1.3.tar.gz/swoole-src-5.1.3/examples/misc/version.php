<?php
echo SWOOLE_VERSION,"\n";
echo swoole_version();
?>
